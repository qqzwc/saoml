#!/bin/bash
name=$1
rm -rf /etc/$name
echo '#SaoML官网：www.saoml.xyz
#saoml流控只能说牛逼
#saoml流控只能说牛逼' >> /etc/$name && chmod 777 /etc/$name